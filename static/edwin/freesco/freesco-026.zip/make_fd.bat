@echo off
cls
echo.
echo This batch file will write the floppy image
echo "freesco.026" onto a disk in drive a:
echo.
echo Insert blank formatted diskette in drive a:
echo.
pause
rawrite -f freesco.026 -d a: