Freesco v0.2.6, released 22/05/00. http://www.freesco.org

Files in this archive
---------------------

date-uix.tgz		UNIX time client for freesco time server.
date-w32.zip		Windows time client for freesco time server.
freesco.026		Raw floppy disk image of freesco.
freesco.scp		Win95/98 dialup networking script for freesco RAS server.
make_fd.bat		Batch file to create a fresh freesco floppy disk.
rawrite.exe		Program to write raw disk images to floppy disk. (used by make_fd.bat)
safe_fd.bat		Batch file to install the syslinux bootloader in safe mode.
fast_fd.bat		Batch file to reverse the changes made by safe_fd.bat without wiping the disk.
syslinux.com		Syslinux installer. (used by safe_fd.bat and fast_fd.bat)

To install
----------

Use make_fd.bat to create a floppy disk, boot from the floppy, run setup, configure your router and reboot.

The default root password is 'root', you should change your password immediately, type the command passwd and enter your new password.

If you have the control http server enabled, you should also change the password for that immediately, the default login and password are both 'admin'. You can change it from the web admin panel itself, or with the command:

	htpasswd /wwa/cgi/.htpasswd admin

Then type your new password.

If you cannot boot past the messages "loading ramdisk....' or "loading kernel....", you can try running safe_fd.bat - it will rewrite the syslinux bootloader to an already created freesco disk, but in safe mode. This may allow freesco to boot on some machines with buggy or non-standard BIOS's. It will boot slower however.

If you have problems with the screen going blank after the point "loading kernel...." which safe_fd.bat does not fix, your vga adaptor may not be compatible with the video mode freesco uses. Edit the following two lines in the file syslinux.cfg on the root directory of the disk:

	append initrd=ramdisk bootdev=fd0 vga=4 no387 no-hlt panic=15 root=/dev/ram0

	append initrd=ramdisk bootdev=fd0 vga=4 no387 no-hlt panic=15 root=/dev/ram0 start=setup

Change the vga entries of both lines to vga=0

If you require the vga=0 setting in order to boot, if you later install freesco to a hard drive you'll need to make the same change to the file router.bat on the hard drive. The two lines will look similar to this:

c:\router\loadlin c:\router\kernel initrd=c:\router\ramdisk bootdev=hda1 root=/dev/ram0 vga=4 no387 no
-hlt panic=15

c:\router\loadlin c:\router\kernel initrd=c:\router\ramdisk bootdev=hda1 root=/dev/ram0 vga=4 no387 no
-hlt panic=15 start=setup

Please refer to the online documentation for any further information.
