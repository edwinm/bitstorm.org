@echo off
cls
echo.
echo This batch file will rewrite the syslinux
echo bootloader in "safe mode" to an existing
echo freesco floppy. Use this only if you cannot
echo boot past loading ramdisk or loading kernel.
echo.
echo Insert an existing freesco diskette in drive a:
echo.
pause
syslinux -s a:
