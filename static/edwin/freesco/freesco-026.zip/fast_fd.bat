@echo off
cls
echo.
echo This batch file will rewrite the syslinux
echo bootloader in "normal mode" to an existing
echo freesco floppy. Use this to reverse the changes
echo made by safe_fd.bat without wiping the other
echo contents of the disk.
echo.
echo Insert an existing freesco diskette in drive a:
echo.
pause
syslinux a:
